var Sketch3D; //name of font 


let eyeSpacing = 10;
let lookAmount;

let newBg = 0;

function setup() { //setup() runs one time before draw()
  createCanvas(400, 400); 
}

function draw (){
  background('#fae');
  
  textSize(60);
  fill(255, 204, 0); // yellow
  stroke(0 , 0 , 250); //blue
 text("I'm Trapped!!!", 25, 70); //write words on screen
   
  fill(255, 204, 0);
  rect(125, 250, 150, 150, 40, 40, 0, 0);
  fill("blue");
  rect(125, 300, 150, 30);
  rect(125, 350, 150, 30);
  noStroke(0);
  fill('red');
  ellipse(200, 200, 150, 150);
  ellipse(250, 200, 100, 100);
  ellipse(150, 200, 100, 100);
  ellipse(250, 150, 75, 75);
  ellipse(150, 150, 75, 75);
  ellipse(150, 250, 75, 75);
  ellipse(250, 250, 75, 75);
  
  fill("black"); 
  square(175, 210, 55, 20);
  fill('white');
  square(185, 212, 10,2);
  square(205, 212, 10,2);
  
 noFill();
  // ellipse(200,200,80,60);
  arc(200,200,80,60, PI/7, 6*PI/7);
  fill(255);
  background(0,0,0,newBg);
  ellipse(200 - eyeSpacing,190,35,35);
  ellipse(200 + eyeSpacing,190,35,35);
  fill(0);
  
  lookAmount = map(mouseX, 0, 400, -15, 15, 1);
  
  
  ellipse(200 - eyeSpacing + lookAmount,190,5,5);
  ellipse(200 + eyeSpacing + lookAmount,190,5,5);
  console.log(mouseX + ', ' + mouseY);
  
}


